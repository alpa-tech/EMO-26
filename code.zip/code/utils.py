import json
import os
import random
from pathlib import Path
import numpy as np
import torch


class AverageMeter:
    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0.0
        self.avg = 0.0
        self.sum = 0.0
        self.count = 0

    def update(self, val, n=1):
        self.val = float(val)
        self.sum += float(val) * n
        self.count += n
        self.avg = self.sum / max(self.count, 1)


def seed_everything(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def get_device(device=None):
    if device is not None:
        return torch.device(device)
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def accuracy(logits, targets):
    preds = logits.argmax(dim=1)
    return (preds == targets).float().mean().item()


def confusion_matrix(y_true, y_pred, num_classes):
    mat = np.zeros((num_classes, num_classes), dtype=np.int64)
    for t, p in zip(y_true, y_pred):
        mat[int(t), int(p)] += 1
    return mat


def classification_metrics(y_true, y_pred, num_classes):
    mat = confusion_matrix(y_true, y_pred, num_classes)
    total = mat.sum()
    acc = np.trace(mat) / total if total > 0 else 0.0
    precision = []
    recall = []
    f1 = []
    support = []
    for i in range(num_classes):
        tp = mat[i, i]
        fp = mat[:, i].sum() - tp
        fn = mat[i, :].sum() - tp
        p = tp / (tp + fp) if tp + fp > 0 else 0.0
        r = tp / (tp + fn) if tp + fn > 0 else 0.0
        f = 2 * p * r / (p + r) if p + r > 0 else 0.0
        precision.append(float(p))
        recall.append(float(r))
        f1.append(float(f))
        support.append(int(mat[i, :].sum()))
    return {
        "accuracy": float(acc),
        "macro_precision": float(np.mean(precision)) if precision else 0.0,
        "macro_recall": float(np.mean(recall)) if recall else 0.0,
        "macro_f1": float(np.mean(f1)) if f1 else 0.0,
        "per_class_precision": precision,
        "per_class_recall": recall,
        "per_class_f1": f1,
        "support": support,
        "confusion_matrix": mat.tolist()
    }


def save_checkpoint(path, model, optimizer=None, scheduler=None, epoch=0, best_metric=0.0, classes=None, args=None):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    obj = {
        "model": model.state_dict(),
        "epoch": int(epoch),
        "best_metric": float(best_metric),
        "classes": classes,
        "args": vars(args) if args is not None else None
    }
    if optimizer is not None:
        obj["optimizer"] = optimizer.state_dict()
    if scheduler is not None:
        obj["scheduler"] = scheduler.state_dict()
    torch.save(obj, path)


def load_checkpoint(path, model=None, optimizer=None, scheduler=None, map_location="cpu"):
    ckpt = torch.load(path, map_location=map_location)
    if model is not None:
        model.load_state_dict(ckpt["model"], strict=True)
    if optimizer is not None and "optimizer" in ckpt:
        optimizer.load_state_dict(ckpt["optimizer"])
    if scheduler is not None and "scheduler" in ckpt:
        scheduler.load_state_dict(ckpt["scheduler"])
    return ckpt


def save_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def ensure_dir(path):
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    return path


def write_csv(path, rows, header):
    import csv
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        writer.writerows(rows)


def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)
