import torch
from torch import nn
import torch.nn.functional as F


class SEBlock(nn.Module):
    def __init__(self, channels, reduction=16):
        super().__init__()
        hidden = max(channels // reduction, 4)
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc1 = nn.Conv2d(channels, hidden, 1)
        self.fc2 = nn.Conv2d(hidden, channels, 1)

    def forward(self, x):
        w = self.pool(x)
        w = F.relu(self.fc1(w), inplace=True)
        w = torch.sigmoid(self.fc2(w))
        return x * w


class ConvBNAct(nn.Module):
    def __init__(self, in_ch, out_ch, kernel_size=3, stride=1, padding=None):
        super().__init__()
        if padding is None:
            padding = kernel_size // 2
        self.net = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, kernel_size, stride, padding, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.GELU()
        )

    def forward(self, x):
        return self.net(x)


class LandmarkBranch(nn.Module):
    def __init__(self, channels=(64, 128, 256)):
        super().__init__()
        c1, c2, c3 = channels
        self.stem = nn.Sequential(
            ConvBNAct(3, c1, 7, 2, 3),
            nn.MaxPool2d(3, 2, 1)
        )
        self.stage1 = nn.Sequential(ConvBNAct(c1, c1), ConvBNAct(c1, c1))
        self.stage2 = nn.Sequential(ConvBNAct(c1, c2, stride=2), ConvBNAct(c2, c2))
        self.stage3 = nn.Sequential(ConvBNAct(c2, c3, stride=2), ConvBNAct(c3, c3))

    def forward(self, x):
        x = self.stem(x)
        f1 = self.stage1(x)
        f2 = self.stage2(f1)
        f3 = self.stage3(f2)
        return f1, f2, f3


class ResNetFeatureBackbone(nn.Module):
    def __init__(self, name="resnet18", pretrained=True):
        super().__init__()
        import torchvision.models as models
        fn = getattr(models, name)
        try:
            weight_map = {
                "resnet18": models.ResNet18_Weights.DEFAULT,
                "resnet34": models.ResNet34_Weights.DEFAULT,
                "resnet50": models.ResNet50_Weights.DEFAULT
            }
            weights = weight_map.get(name, None) if pretrained else None
            net = fn(weights=weights)
        except Exception:
            net = fn(pretrained=pretrained)
        self.stem = nn.Sequential(net.conv1, net.bn1, net.relu, net.maxpool)
        self.layer1 = net.layer1
        self.layer2 = net.layer2
        self.layer3 = net.layer3
        if name in ["resnet18", "resnet34"]:
            self.out_channels = (64, 128, 256)
        else:
            self.out_channels = (256, 512, 1024)

    def forward(self, x):
        x = self.stem(x)
        f1 = self.layer1(x)
        f2 = self.layer2(f1)
        f3 = self.layer3(f2)
        return f1, f2, f3


class ScaleTokenizer(nn.Module):
    def __init__(self, dim, token_size=7):
        super().__init__()
        self.pool = nn.AdaptiveAvgPool2d((token_size, token_size))
        self.norm = nn.LayerNorm(dim)

    def forward(self, x):
        x = self.pool(x)
        x = x.flatten(2).transpose(1, 2)
        return self.norm(x)


class SEPoster(nn.Module):
    def __init__(
        self,
        num_classes=7,
        backbone="resnet18",
        pretrained=True,
        embed_dim=256,
        reduction=16,
        token_size=7,
        depth=4,
        heads=8,
        mlp_ratio=4.0,
        dropout=0.1,
        freeze_backbone=False
    ):
        super().__init__()
        self.image_backbone = ResNetFeatureBackbone(backbone, pretrained)
        self.landmark_backbone = LandmarkBranch(self.image_backbone.out_channels)
        channels = self.image_backbone.out_channels
        self.fuse = nn.ModuleList([nn.Conv2d(c * 2, embed_dim, 1, bias=False) for c in channels])
        self.fuse_bn = nn.ModuleList([nn.BatchNorm2d(embed_dim) for _ in channels])
        self.se = nn.ModuleList([SEBlock(embed_dim, reduction) for _ in channels])
        self.tokenizers = nn.ModuleList([ScaleTokenizer(embed_dim, token_size) for _ in channels])
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=embed_dim,
            nhead=heads,
            dim_feedforward=int(embed_dim * mlp_ratio),
            dropout=dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=depth)
        total_tokens = len(channels) * token_size * token_size
        self.pos_embed = nn.Parameter(torch.zeros(1, total_tokens, embed_dim))
        self.scale_embed = nn.Parameter(torch.zeros(1, len(channels), 1, embed_dim))
        self.norm = nn.LayerNorm(embed_dim)
        self.head = nn.Sequential(
            nn.Linear(embed_dim, embed_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(embed_dim, num_classes)
        )
        self._init_weights()
        if freeze_backbone:
            for p in self.image_backbone.parameters():
                p.requires_grad = False

    def _init_weights(self):
        nn.init.trunc_normal_(self.pos_embed, std=0.02)
        nn.init.trunc_normal_(self.scale_embed, std=0.02)
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.trunc_normal_(m.weight, std=0.02)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode="fan_out")
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            if isinstance(m, (nn.BatchNorm2d, nn.LayerNorm)):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)

    def forward_features(self, image, landmark_image=None):
        if landmark_image is None:
            landmark_image = image
        image_feats = self.image_backbone(image)
        landmark_feats = self.landmark_backbone(landmark_image)
        tokens = []
        refined_features = []
        for i, (img, lm) in enumerate(zip(image_feats, landmark_feats)):
            if lm.shape[-2:] != img.shape[-2:]:
                lm = F.interpolate(lm, size=img.shape[-2:], mode="bilinear", align_corners=False)
            x = torch.cat([img, lm], dim=1)
            x = F.gelu(self.fuse_bn[i](self.fuse[i](x)))
            x = self.se[i](x)
            refined_features.append(x)
            t = self.tokenizers[i](x)
            t = t + self.scale_embed[:, i]
            tokens.append(t)
        x = torch.cat(tokens, dim=1)
        x = x + self.pos_embed[:, :x.shape[1]]
        x = self.transformer(x)
        x = self.norm(x)
        return x.mean(dim=1), refined_features

    def forward(self, image, landmark_image=None, return_features=False):
        x, refined_features = self.forward_features(image, landmark_image)
        logits = self.head(x)
        if return_features:
            return logits, refined_features
        return logits


def build_model(num_classes=7, **kwargs):
    return SEPoster(num_classes=num_classes, **kwargs)
