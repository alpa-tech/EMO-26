from PIL import Image
from torchvision import transforms


DEFAULT_MEAN = (0.485, 0.456, 0.406)
DEFAULT_STD = (0.229, 0.224, 0.225)


def resolve_stats(mean=None, std=None):
    mean = DEFAULT_MEAN if mean is None else tuple(mean)
    std = DEFAULT_STD if std is None else tuple(std)
    return mean, std


def build_train_transform(image_size=224, mean=None, std=None):
    mean, std = resolve_stats(mean, std)
    return transforms.Compose([
        transforms.Resize((image_size, image_size)),
        transforms.RandomHorizontalFlip(p=0.5),
        transforms.RandomApply([transforms.ColorJitter(0.2, 0.2, 0.2, 0.05)], p=0.5),
        transforms.RandomAffine(degrees=10, translate=(0.05, 0.05), scale=(0.95, 1.05)),
        transforms.ToTensor(),
        transforms.Normalize(mean, std)
    ])


def build_eval_transform(image_size=224, mean=None, std=None):
    mean, std = resolve_stats(mean, std)
    return transforms.Compose([
        transforms.Resize((image_size, image_size)),
        transforms.ToTensor(),
        transforms.Normalize(mean, std)
    ])


def load_rgb_image(path):
    return Image.open(path).convert("RGB")


def denormalize(tensor, mean=None, std=None):
    mean, std = resolve_stats(mean, std)
    mean = tensor.new_tensor(mean).view(-1, 1, 1)
    std = tensor.new_tensor(std).view(-1, 1, 1)
    return tensor * std + mean
