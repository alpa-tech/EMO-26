import argparse
from contextlib import nullcontext
from pathlib import Path
import torch
from torch import nn
from torch.utils.data import DataLoader
from torch.cuda.amp import GradScaler, autocast
from dataset import build_datasets
from model import build_model
from utils import AverageMeter, accuracy, count_parameters, ensure_dir, get_device, save_checkpoint, save_json, seed_everything


def run_train_epoch(model, loader, criterion, optimizer, device, scaler, amp_enabled):
    model.train()
    loss_meter = AverageMeter()
    acc_meter = AverageMeter()
    for images, targets in loader:
        images = images.to(device, non_blocking=True)
        targets = targets.to(device, non_blocking=True)
        optimizer.zero_grad(set_to_none=True)
        ctx = autocast(enabled=amp_enabled) if device.type == "cuda" else nullcontext()
        with ctx:
            logits = model(images)
            loss = criterion(logits, targets)
        scaler.scale(loss).backward()
        if scaler.is_enabled():
            scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
        scaler.step(optimizer)
        scaler.update()
        bs = images.size(0)
        loss_meter.update(loss.item(), bs)
        acc_meter.update(accuracy(logits.detach(), targets), bs)
    return loss_meter.avg, acc_meter.avg


def run_eval_epoch(model, loader, criterion, device, amp_enabled):
    model.eval()
    loss_meter = AverageMeter()
    acc_meter = AverageMeter()
    with torch.no_grad():
        for batch in loader:
            images = batch[0].to(device, non_blocking=True)
            targets = batch[1].to(device, non_blocking=True)
            ctx = autocast(enabled=amp_enabled) if device.type == "cuda" else nullcontext()
            with ctx:
                logits = model(images)
                loss = criterion(logits, targets)
            bs = images.size(0)
            loss_meter.update(loss.item(), bs)
            acc_meter.update(accuracy(logits, targets), bs)
    return loss_meter.avg, acc_meter.avg


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data_dir", type=str, required=True)
    p.add_argument("--output_dir", type=str, default="runs/se_poster")
    p.add_argument("--image_size", type=int, default=224)
    p.add_argument("--batch_size", type=int, default=32)
    p.add_argument("--epochs", type=int, default=300)
    p.add_argument("--lr", type=float, default=1e-4)
    p.add_argument("--weight_decay", type=float, default=1e-4)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--num_workers", type=int, default=4)
    p.add_argument("--backbone", type=str, default="resnet18")
    p.add_argument("--pretrained", action="store_true")
    p.add_argument("--embed_dim", type=int, default=256)
    p.add_argument("--depth", type=int, default=4)
    p.add_argument("--heads", type=int, default=8)
    p.add_argument("--token_size", type=int, default=7)
    p.add_argument("--dropout", type=float, default=0.1)
    p.add_argument("--label_smoothing", type=float, default=0.0)
    p.add_argument("--amp", action="store_true")
    p.add_argument("--device", type=str, default=None)
    return p.parse_args()


def main():
    args = parse_args()
    seed_everything(args.seed)
    device = get_device(args.device)
    output_dir = ensure_dir(args.output_dir)
    train_set, val_set, test_set = build_datasets(args.data_dir, args.image_size)
    train_loader = DataLoader(train_set, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers, pin_memory=True)
    val_loader = DataLoader(val_set, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=True)
    model = build_model(
        num_classes=len(train_set.classes),
        backbone=args.backbone,
        pretrained=args.pretrained,
        embed_dim=args.embed_dim,
        token_size=args.token_size,
        depth=args.depth,
        heads=args.heads,
        dropout=args.dropout
    ).to(device)
    criterion = nn.CrossEntropyLoss(label_smoothing=args.label_smoothing)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
    scaler = GradScaler(enabled=args.amp and device.type == "cuda")
    amp_enabled = args.amp and device.type == "cuda"
    best_acc = 0.0
    save_json(output_dir / "classes.json", {"classes": train_set.classes, "class_to_idx": train_set.class_to_idx})
    print(f"device={device}")
    print(f"classes={len(train_set.classes)}")
    print(f"parameters={count_parameters(model)}")
    for epoch in range(1, args.epochs + 1):
        train_loss, train_acc = run_train_epoch(model, train_loader, criterion, optimizer, device, scaler, amp_enabled)
        val_loss, val_acc = run_eval_epoch(model, val_loader, criterion, device, amp_enabled)
        scheduler.step()
        if val_acc > best_acc:
            best_acc = val_acc
            save_checkpoint(output_dir / "best_se_poster.pt", model, optimizer, scheduler, epoch, best_acc, train_set.classes, args)
        save_checkpoint(output_dir / "last_se_poster.pt", model, optimizer, scheduler, epoch, best_acc, train_set.classes, args)
        print(f"epoch={epoch} train_loss={train_loss:.6f} train_acc={train_acc:.6f} val_loss={val_loss:.6f} val_acc={val_acc:.6f} best_acc={best_acc:.6f}")


if __name__ == "__main__":
    main()
