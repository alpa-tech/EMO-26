from pathlib import Path
from PIL import Image
from torch.utils.data import Dataset
from torchvision.datasets import ImageFolder
from preprocessing import build_train_transform, build_eval_transform


class FERImageFolder(ImageFolder):
    def __init__(self, root, transform=None, return_path=False):
        super().__init__(root=root, transform=transform)
        self.return_path = return_path

    def __getitem__(self, index):
        path, target = self.samples[index]
        sample = self.loader(path)
        if self.transform is not None:
            sample = self.transform(sample)
        if self.return_path:
            return sample, target, path
        return sample, target


class SingleImageDataset(Dataset):
    def __init__(self, paths, transform=None):
        self.paths = [str(p) for p in paths]
        self.transform = transform

    def __len__(self):
        return len(self.paths)

    def __getitem__(self, index):
        path = self.paths[index]
        image = Image.open(path).convert("RGB")
        if self.transform is not None:
            image = self.transform(image)
        return image, path


def build_datasets(data_dir, image_size=224, mean=None, std=None):
    data_dir = Path(data_dir)
    train_tf = build_train_transform(image_size, mean, std)
    eval_tf = build_eval_transform(image_size, mean, std)
    train_set = FERImageFolder(data_dir / "train", transform=train_tf)
    val_set = FERImageFolder(data_dir / "val", transform=eval_tf)
    test_root = data_dir / "test"
    test_set = FERImageFolder(test_root, transform=eval_tf, return_path=True) if test_root.exists() else None
    return train_set, val_set, test_set


def collect_images(path):
    path = Path(path)
    if path.is_file():
        return [path]
    exts = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
    return sorted([p for p in path.rglob("*") if p.suffix.lower() in exts])
