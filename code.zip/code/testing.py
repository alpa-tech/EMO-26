import argparse
from pathlib import Path
import torch
from torch.utils.data import DataLoader
from dataset import SingleImageDataset, collect_images
from model import build_model
from preprocessing import build_eval_transform
from utils import get_device, load_checkpoint, write_csv


def model_kwargs(saved_args):
    saved_args = saved_args or {}
    return {
        "backbone": saved_args.get("backbone", "resnet18"),
        "pretrained": False,
        "embed_dim": saved_args.get("embed_dim", 256),
        "token_size": saved_args.get("token_size", 7),
        "depth": saved_args.get("depth", 4),
        "heads": saved_args.get("heads", 8),
        "dropout": saved_args.get("dropout", 0.1)
    }


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--checkpoint", type=str, required=True)
    p.add_argument("--image", type=str, required=True)
    p.add_argument("--output_csv", type=str, default="predictions.csv")
    p.add_argument("--batch_size", type=int, default=32)
    p.add_argument("--num_workers", type=int, default=2)
    p.add_argument("--image_size", type=int, default=None)
    p.add_argument("--topk", type=int, default=3)
    p.add_argument("--device", type=str, default=None)
    return p.parse_args()


def main():
    args = parse_args()
    device = get_device(args.device)
    ckpt = torch.load(args.checkpoint, map_location="cpu")
    saved_args = ckpt.get("args") or {}
    image_size = args.image_size or saved_args.get("image_size", 224)
    classes = ckpt.get("classes") or [str(i) for i in range(7)]
    model = build_model(num_classes=len(classes), **model_kwargs(saved_args)).to(device)
    load_checkpoint(args.checkpoint, model=model, map_location=device)
    model.eval()
    paths = collect_images(args.image)
    transform = build_eval_transform(image_size)
    dataset = SingleImageDataset(paths, transform)
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=True)
    rows = []
    with torch.no_grad():
        for images, batch_paths in loader:
            images = images.to(device, non_blocking=True)
            logits = model(images)
            probs = torch.softmax(logits, dim=1)
            k = min(args.topk, probs.shape[1])
            values, indices = torch.topk(probs, k=k, dim=1)
            for path, vals, inds in zip(batch_paths, values.cpu(), indices.cpu()):
                pred_idx = int(inds[0])
                pred_label = classes[pred_idx]
                confidence = float(vals[0])
                top_items = [f"{classes[int(i)]}:{float(v):.6f}" for v, i in zip(vals, inds)]
                rows.append([path, pred_idx, pred_label, f"{confidence:.6f}", "|".join(top_items)])
    write_csv(args.output_csv, rows, ["path", "pred_index", "pred_label", "confidence", "topk"])
    for row in rows[:20]:
        print(",".join(map(str, row)))
    print(f"saved={args.output_csv}")


if __name__ == "__main__":
    main()
