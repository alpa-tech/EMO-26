import argparse
from pathlib import Path
import torch
from torch.utils.data import DataLoader
from dataset import FERImageFolder
from model import build_model
from preprocessing import build_eval_transform
from utils import classification_metrics, get_device, load_checkpoint, save_json, write_csv


def model_kwargs(saved_args):
    saved_args = saved_args or {}
    return {
        "backbone": saved_args.get("backbone", "resnet18"),
        "pretrained": False,
        "embed_dim": saved_args.get("embed_dim", 256),
        "token_size": saved_args.get("token_size", 7),
        "depth": saved_args.get("depth", 4),
        "heads": saved_args.get("heads", 8),
        "dropout": saved_args.get("dropout", 0.1)
    }


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--checkpoint", type=str, required=True)
    p.add_argument("--data_dir", type=str, default=None)
    p.add_argument("--test_dir", type=str, default=None)
    p.add_argument("--output_dir", type=str, default="eval_outputs")
    p.add_argument("--batch_size", type=int, default=32)
    p.add_argument("--num_workers", type=int, default=4)
    p.add_argument("--image_size", type=int, default=None)
    p.add_argument("--device", type=str, default=None)
    return p.parse_args()


def main():
    args = parse_args()
    test_dir = Path(args.test_dir) if args.test_dir else Path(args.data_dir) / "test"
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    device = get_device(args.device)
    ckpt = torch.load(args.checkpoint, map_location="cpu")
    saved_args = ckpt.get("args") or {}
    image_size = args.image_size or saved_args.get("image_size", 224)
    transform = build_eval_transform(image_size)
    dataset = FERImageFolder(test_dir, transform=transform, return_path=True)
    classes = ckpt.get("classes") or dataset.classes
    model = build_model(num_classes=len(classes), **model_kwargs(saved_args)).to(device)
    load_checkpoint(args.checkpoint, model=model, map_location=device)
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=True)
    model.eval()
    y_true = []
    y_pred = []
    rows = []
    with torch.no_grad():
        for images, targets, paths in loader:
            images = images.to(device, non_blocking=True)
            logits = model(images)
            probs = torch.softmax(logits, dim=1)
            pred = probs.argmax(dim=1).cpu()
            conf = probs.max(dim=1).values.cpu()
            for path, t, p, c in zip(paths, targets, pred, conf):
                ti = int(t)
                pi = int(p)
                y_true.append(ti)
                y_pred.append(pi)
                true_label = dataset.classes[ti]
                pred_label = classes[pi]
                rows.append([path, ti, true_label, pi, pred_label, f"{float(c):.6f}"])
    metrics = classification_metrics(y_true, y_pred, len(classes))
    metrics["classes"] = classes
    save_json(output_dir / "metrics.json", metrics)
    write_csv(output_dir / "predictions.csv", rows, ["path", "true_index", "true_label", "pred_index", "pred_label", "confidence"])
    print(f"accuracy={metrics['accuracy']:.6f}")
    print(f"macro_f1={metrics['macro_f1']:.6f}")
    print(f"saved={output_dir}")


if __name__ == "__main__":
    main()
